class Table{
	public static void main(String[] args) {
		
		int a = 40;

		while(a != 0){

			System.out.print(a + " ");
			a-=4;
		}
		System.out.println();
	}
}