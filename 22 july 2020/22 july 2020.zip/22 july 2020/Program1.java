class EvenOdd {

	public static void main(String[] args) {
		
		int x = 10;

		String result ;

		result = (x % 2 == 0) ? "10 is Even" : "10 is Odd";

		System.out.println(result);
	}
}