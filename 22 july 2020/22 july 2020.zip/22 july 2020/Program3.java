class Voting {

	public static void main(String[] args) {
		
		int age = 16;

		String vote ;

		vote = (age >= 18) ? "Eligible For Voting" : "Not Eligible for Voting";

		System.out.println(vote);
	}
}