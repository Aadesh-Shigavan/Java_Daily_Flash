class UpperLower {

	public static void main(String[] args) {
		
		char character = 'A';

		if (character == 'A') {
			System.out.println("a");
		}
		else{
			System.out.println("A");
		}
	}
}