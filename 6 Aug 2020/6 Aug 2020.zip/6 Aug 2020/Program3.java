class Pattern {

	public static void main(String[] args) {
		
		for (int i = 1; i < 6; i++){
			System.out.print("Ab");
		}
		System.out.println("");
	}
}